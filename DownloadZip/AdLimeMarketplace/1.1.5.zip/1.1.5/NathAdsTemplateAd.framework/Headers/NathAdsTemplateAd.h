//
//  NathAdsTemplateAd.h
//  NathAdsTemplateAd
//
//  Created by zena.tang on 2020/4/24.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NathAdsTemplateAd.
FOUNDATION_EXPORT double NathAdsTemplateAdVersionNumber;

//! Project version string for NathAdsTemplateAd.
FOUNDATION_EXPORT const unsigned char NathAdsTemplateAdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NathAdsTemplateAd/PublicHeader.h>

#import <NathAdsTemplateAd/NATAError.h>
#import <NathAdsTemplateAd/NATAAdCreative.h>
#import <NathAdsTemplateAd/NATAExpressAd.h>
#import <NathAdsTemplateAd/NATAManager.h>
#import <NathAdsTemplateAd/NATATemplateView.h>
