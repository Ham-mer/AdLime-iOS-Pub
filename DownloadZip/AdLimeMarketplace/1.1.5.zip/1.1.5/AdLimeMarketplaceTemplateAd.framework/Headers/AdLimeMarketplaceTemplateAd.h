//
//  AdLimeMarketplaceTemplateAd.h
//  AdLimeMarketplaceTemplateAd
//
//  Created by nathads on 2020/4/24.
//  Copyright © 2020 nathads. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AdLimeMarketplaceTemplateAd.
FOUNDATION_EXPORT double AdLimeMarketplaceTemplateAdVersionNumber;

//! Project version string for AdLimeMarketplaceTemplateAd.
FOUNDATION_EXPORT const unsigned char AdLimeMarketplaceTemplateAdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdLimeMarketplaceTemplateAd/PublicHeader.h>

#import <AdLimeMarketplaceTemplateAd/AdLimeMTAError.h>
#import <AdLimeMarketplaceTemplateAd/AdLimeMTAAdCreative.h>
#import <AdLimeMarketplaceTemplateAd/AdLimeMTAExpressAd.h>
#import <AdLimeMarketplaceTemplateAd/AdLimeMTAManager.h>
#import <AdLimeMarketplaceTemplateAd/AdLimeMTATemplateView.h>
