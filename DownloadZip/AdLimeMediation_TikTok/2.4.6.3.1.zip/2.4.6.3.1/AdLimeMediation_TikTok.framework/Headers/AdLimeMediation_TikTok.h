//
//  AdLimeMediation_TikTok.h
//  AdLimeMediation_TikTok
//
//  Created by Mathew on 2019/7/3.
//  Copyright © 2019年 AdLime. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdLimeMediation_TikTok.
FOUNDATION_EXPORT double AdLimeMediation_TikTokVersionNumber;

//! Project version string for AdLimeMediation_TikTok.
FOUNDATION_EXPORT const unsigned char AdLimeMediation_TikTokVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdLimeMediation_TikTok/PublicHeader.h>

#import <AdLimeMediation_TikTok/AdLimeTikTokExpressFeedListConfig.h>
#import <AdLimeMediation_TikTok/AdLimeTikTokSplashConfig.h>
