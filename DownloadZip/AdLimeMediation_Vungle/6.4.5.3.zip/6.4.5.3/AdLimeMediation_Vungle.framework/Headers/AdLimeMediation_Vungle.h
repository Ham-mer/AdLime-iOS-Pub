//
//  AdLimeMediation_Vungle.h
//  AdLimeMediation_Vungle
//
//  Created by AdLimeSdk on 2019/8/8.
//  Copyright © 2019 AdLime. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdLimeMediation_Vungle.
FOUNDATION_EXPORT double AdLimeMediation_VungleVersionNumber;

//! Project version string for AdLimeMediation_Vungle.
FOUNDATION_EXPORT const unsigned char AdLimeMediation_VungleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdLimeMediation_Vungle/PublicHeader.h>

#import <AdLimeMediation_Vungle/AdLimeVungleInFeedConfig.h>


