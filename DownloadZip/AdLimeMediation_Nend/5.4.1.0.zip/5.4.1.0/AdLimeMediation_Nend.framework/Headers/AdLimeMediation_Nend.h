//
//  AdLimeMediation_Nend.h
//  AdLimeMediation_Nend
//
//  Created by AdLimeSdk on 2019/6/27.
//  Copyright © 2019年 AdLimeSdk. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdLimeMediation_Nend.
FOUNDATION_EXPORT double AdLimeMediation_NendVersionNumber;

//! Project version string for AdLimeMediation_Nend.
FOUNDATION_EXPORT const unsigned char AdLimeMediation_NendVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdLimeMediation_Nend/PublicHeader.h>

#import <AdLimeMediation_Nend/AdLimeNendAdMode.h>
