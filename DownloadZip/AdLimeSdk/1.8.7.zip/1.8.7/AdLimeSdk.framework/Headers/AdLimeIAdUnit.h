//
//  AdLimeIAdUnit.h
//  AdLimeSdk
//
//  Created by AdLimeSdk on 2020/2/1.
//  Copyright © 2020 AdLimeSdk. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AdLimeIAdUnit : NSObject

-(NSString *)getName;
-(NSString *)getId;

@end

NS_ASSUME_NONNULL_END
