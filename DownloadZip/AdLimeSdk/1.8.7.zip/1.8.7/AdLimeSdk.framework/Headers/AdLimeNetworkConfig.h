//
//  AdLimeNetworkConfig.h
//  AdLimeSdk
//
//  Created by AdLimeSdk on 2019/10/8.
//  Copyright © 2019年 AdLimeSdk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdLimeNetworkConfig : NSObject

-(void)log:(NSString *)message;

@end
