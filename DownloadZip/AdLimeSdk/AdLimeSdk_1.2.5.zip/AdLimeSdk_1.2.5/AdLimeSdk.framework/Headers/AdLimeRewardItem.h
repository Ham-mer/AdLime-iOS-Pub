//
//  AdLimeRewardItem.h
//

#import <Foundation/Foundation.h>

@interface AdLimeRewardItem : NSObject

@property NSString *rewardType;
@property int rewardAmount;

@end
