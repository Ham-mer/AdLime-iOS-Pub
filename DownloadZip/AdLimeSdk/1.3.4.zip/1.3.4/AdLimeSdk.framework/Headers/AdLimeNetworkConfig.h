//
//  AdLimeNetworkConfig.h
//  AdLimeSdk
//
//  Created by Matthew on 2019/10/8.
//  Copyright © 2019年 AdLime. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdLimeNetworkConfig : NSObject

-(void)log:(NSString *)message;

@end
